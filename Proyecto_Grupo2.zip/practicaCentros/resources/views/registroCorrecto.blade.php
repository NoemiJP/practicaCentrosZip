@extends('portada')
@section('contenido')
<h1>Ha sido registrado correctamente en el sistema</h1>
@endsection