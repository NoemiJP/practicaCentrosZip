
<?php $__env->startSection('contenido'); ?>
    <section class="seccionLogin">
        <div class="formulario formulario-registro">
            <div class="valores">
                <form method="POST"  action="/usuarios/registrar">
                    <?php echo csrf_field(); ?>
                    <h2>Formulario de Registro</h2>
                    <div class="entrada">
                        <label for="nombre">Nombre</label><br>
                        <input type="text" name="nombre" id="nombre" placeholder="Ingrese su nombre"><br><br>
                        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color: red;"><?php echo e($message); ?></span><br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="entrada">
                        <label for="apellidos">Apellidos</label><br>
                        <input type="text" name="apellidos" id="apellidos" placeholder="Ingrese sus apellidos"><br><br>
                        <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color: red;"><?php echo e($message); ?></span><br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="entrada">
                        <label for="email">Correo eléctronico</label><br>
                        <input type="email" name="email" id="email" placeholder="Ingrese su nombre correo"><br><br>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color: red;"><?php echo e($message); ?></span><br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="entrada">
                        <label for="usuario">Usuario</label><br>
                        <input type="text" name="usuario" id="usu"
                            placeholder="Ingrese el usuario que desee" /><br><br>
                        <?php $__errorArgs = ['usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color: red;"><?php echo e($message); ?></span><br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="entrada">
                        <label for="contrasena">Contraseña</label><br>
                        <input type="password" name="contrasena" id="pass" placeholder="Ingrese su contraseña"><br><br>
                        <?php $__errorArgs = ['contraseña'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color: red;"><?php echo e($message); ?></span><br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="entrada">
                        <label for="centro">Centro</label>
                        <select name="centro" id="centro">
                            <option value="IBQ">IES Bernaldo de Quirós (IBQ)</option>
                            <option value="IBCF">IES Blas Cabrera Felipe (IBCF)</option>
                            <option value="IPCC">IES Pasqual Calbó i Caldés (IPCC)</option>
                            <option value="IPJB">IES Profesor Juan Bautista (IPJB)</option>
                            <option value="IMSIS">INS Manresa SIS (IMSIS) </option>
                        </select><br><br>
                        <?php $__errorArgs = ['centro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span style="color: red;"><?php echo e($message); ?></span><br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <input class="boton" type="submit" value="Registrarse">
                    <input type="hidden" name="rol" value="invitado">
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('portada', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practicaCentros\resources\views/registro.blade.php ENDPATH**/ ?>