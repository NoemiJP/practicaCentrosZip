
<?php $__env->startSection('contenido'); ?>
<h1>Ha sido registrado correctamente en el sistema</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('portada', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practicaCentros\resources\views/registroCorrecto.blade.php ENDPATH**/ ?>