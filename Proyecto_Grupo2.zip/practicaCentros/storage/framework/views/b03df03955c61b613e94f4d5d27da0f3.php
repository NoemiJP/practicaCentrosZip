
<?php $__env->startSection('contenido'); ?>
    <main class="margen2 ancho">
        <h1 class="tituloPag">Experiencias Administrador</h1>
        <div class="row justify-content-center">

            <!-- Itera sobre cada experiencia para mostrarla en una tarjeta -->
            <?php $__currentLoopData = $experiencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experiencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card col-12 align-self-center margen" style="width: 18rem;">
                    <h5 class="card-header"><?php echo e($experiencia->titulo); ?></h5>
                    <div class="card-body">
                        <p class="card-title"><?php echo e($experiencia->texto); ?></p>
                        <p class="card-text"><?php echo e($experiencia->centro); ?></p>
                        <?php $__currentLoopData = $archivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($archivo->experiencias_id == $experiencia->id): ?>
                                <p class="card-text"><img
                                        src="data:image/jpg; base64, <?php echo e(base64_encode($archivo->archivo)); ?>"
                                        alt="img experiencia"></p>
                            <?php endif; ?>

            <!-- Botón para validar la experiencia, redirige a la ruta /validar con los IDs-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <a href="/validar/<?php echo e($experiencia->id); ?>/<?php echo e($usuario->id); ?>"
                            class="btn btn-success float-right">Validar Experiencia</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('portada', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practicaCentros\resources\views/experienciasAdmin.blade.php ENDPATH**/ ?>