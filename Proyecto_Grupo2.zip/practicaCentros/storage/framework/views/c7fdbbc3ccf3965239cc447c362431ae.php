
<?php $__env->startSection('contenido'); ?>
    <main class="margen2">
        <h1>Experiencias Publicadas</h1>
        <div class="row justify-content-center">
            <!-- Itera sobre cada experiencia para mostrarla en una tarjeta -->
            <?php $__currentLoopData = $experiencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experiencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="<?php echo e($experiencia->centro); ?>" class="card col-9 align-self-center margen" style="width: 18rem;">
                   
                  <!-- Encabezado de la tarjeta-->
                    <h5 class="card-header"><?php echo e($experiencia->titulo); ?></h5>

                      <!-- Cuerpo de la tarjeta: texto de la experiencia, centro y usuario -->
                    <div class="card-body">
                        <p class="card-title"><?php echo e($experiencia->texto); ?></p>
                        <p class="card-text">Centro: <?php echo e($experiencia->centro); ?></p>
                        <p class="card-text">Usuario: <?php echo e($experiencia->usuario); ?></p>

                        <!-- Itera sobre la lista de archivos,si el ID de la experiencia
                                   coincide con el de los archivos, se muestra la imagen -->
                        <?php $__currentLoopData = $archivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($archivo->experiencias_id == $experiencia->id): ?>
                                <p class="card-text"><img
                                        src="data:image/jpg; base64, <?php echo e(base64_encode($archivo->archivo)); ?>"
                                        alt="img experiencia"></p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </main>
    <script>
        $(document).ready(function() {
            // Cambiar el color de fondo de los elementos según su ID
            $("div[id*='IBQ']").css("background-color", "#D4EFDF");

            $("div[id*='IPCC']").css("background-color", "#F5B7B1");

            $("div[id*='IBCF']").css("background-color", "#D6EAF8");

            $("div[id*='IMSIS']").css("background-color", "#FDEBD0");

            $("div[id*='IPJB']").css("background-color", "#EBDEF0 ");


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('portada', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practicaCentros\resources\views/listadoExperiencias.blade.php ENDPATH**/ ?>